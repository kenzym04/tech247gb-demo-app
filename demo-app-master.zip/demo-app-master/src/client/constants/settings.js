export const JWT_TOKEN = 'JWT_TOKEN'
