export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const LOAD_MY_TASK = 'LOAD_MY_TASK'
