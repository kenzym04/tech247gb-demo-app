# Mawingu Admin

Admin app for Mawingu

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

Install NodeJs version v10.16.0 or above. Install mysql version and import database to mysql

### Installing

A step by step series of examples that tell you how to get a development env running

Switch to project folder and do npm install

```
npm install
```

## Running API

Switch to server folder

```
cd src/server
```

Customise the environments by editing .env file

```
PORT=3001  \\Port on which app need to listen
JWT_SECRET='supertajneheslo'  \\JWT secret
CORS_DOMIANS='http://localhost:3000'  \\Comma seperated list of domains where cros is need to be enabled
MYSQL_DB='demoApp' \\Mysql Database Name
MYSQL_USER_NAME='root' \\Mysql User Name
MYSQL_PASSWORD='' \\Mysql Password
MYSQL_HOST='localhost' \\Mysql Host
MYSQL_PORT='3306' \\Mysql Port
```

Run the server

```
npm run server
```

The server start listening on http://localhost:3001

## Running the React App

Switch to client folder

```
cd src/client
```

Customise the environments by editing .env file

```
REACT_APP_API_URL=http://localhost:3001 \\ API URL path
```

Run the client

```
npm start
```

The App start listening on http://localhost:3000

## Deploying API

Install [pm2](http://pm2.keymetrics.io/)

```
npm install pm2 -g
```

Switch to server folder

```
cd src/server
```

Customise the environments by editing .env file and run the server

```
pm2 start index.js
```

The server start listening on http://localhost:3001.Configure any webservice like `apache` or `nginx` in such a way that api domain get forwarded to local url

## Deploying React App

Switch to client folder

```
cd src/client
```

Customise the environments by editing .env file

Build the client

```
npm run buld
```

This will create build files in build folder in `src/client/build`
.Configure any webservice like `apache` or `nginx` with `src/client/build` as document root for the React app domain
